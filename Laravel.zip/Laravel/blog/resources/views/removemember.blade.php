@extends('layout/master')

@section('content')


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body style="background-color:skyblue">
   

    @foreach ($members as $m) 
    <div class="card" style="width: 25rem; margin-top:90px;margin-left:-510px;display:inline-block">
        <img src="{{ asset('images/'.$m->pimg) }}" class="card-img-top" alt="..." style="height:170px;width:250px;border-radius:5%">
        {{-- <div class="card-body">
             </div> --}}
        <ul class="list-group list-group-flush">
        <li class="list-group-item">Name: {{ $m->name }}</li>
          <li class="list-group-item">Emp ID: {{ $m->empid }}</li>
          <li class="list-group-item">Email: {{ $m->email }}</li>
          <li class="list-group-item">Mobile: {{ $m->mobile }}</li>
          <li class="list-group-item">Date of Joining: {{ $m->joiningdate }}</li>
        </ul>

    <form action="/members/{{ $m->id }}" method="POST">
        @csrf
        {{method_field('DELETE')}}

        <input type="submit" name="submit" value="Delete Member" class="btn btn-danger" style="margin-top:-30px;width:248px">
    
    </form>
      </div>

    @endforeach

    

</body>
</html>


@endsection