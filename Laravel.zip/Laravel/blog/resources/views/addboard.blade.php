
@extends('layout/master')

@section('content')
    
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Add Board</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="../fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		
		
		<link rel="stylesheet" href="{{asset('css/style.css')}}">
	</head>

	<body >
<div class="wrapper" style="margin-left:234px;margin-top:-110px;background-image: url({{ asset('images/bg-registration-form-2.jpg')}});height:400px;margin-top:15px;width:2000px;">
			<div class="inner" style="margin-top:-0px;">
			<form action="boards" method="POST" enctype="multipart/form-data">
					@csrf
					
					<h3 style="margin-top:-18px;margin-left:-180px;">Enter Board Details</h3>
					<div class="form-group" style="margin-left:-65px;">
						<div class="form-wrapper">
							<label >Name</label>
							<input type="text" class="form-control" name="name">
						</div>
                        <div class="form-wrapper">
						<label >Email</label>
						<input type="email" class="form-control" name="email">
					</div>
                    <div class="form-wrapper" style="margin-left:20px;">
						<label >Mobile</label>
						<input type="tel" class="form-control" name="mobile">
                    </div>
                    </div>
                    

                    <div class="form-group" style="margin-left:-65px;">
						
					
                    <div class="form-wrapper" style="margin-left:2px;">
						<label >EMP ID</label>
						<input type="number" class="form-control" name="empid">
					</div>
					<div class="form-wrapper" style="margin-left:4px;">
						<label >Role</label>
						<input type="text" class="form-control" name="role">
                    </div>
                    <div class="form-wrapper" style="margin-left:20px;">
						<label >Date of Joining</label>
						<input type="date" class="form-control" name="doj">
                    </div>
                    <div class="form-wrapper" style="margin-left:20px;">
						<label >Profile Picture</label>
						<input type="file" class="form-control" name="profileimg">
					</div>
					</div>
					
					<button name="addboard" style="margin-left:187px;">Add Board</button>
				</form>
			</div>
        </div>
        
    </body>
    </html>
    
@endsection


        
		
	