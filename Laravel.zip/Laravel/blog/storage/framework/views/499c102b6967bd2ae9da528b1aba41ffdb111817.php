<?php $__env->startSection('content'); ?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<body style="background-color:skyblue">
   

    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <div class="card" style="width: 25rem; margin-top:90px;margin-left:-510px;display:inline-block">
        <img src="<?php echo e(asset('images/'.$m->pimg)); ?>" class="card-img-top" alt="..." style="height:170px;width:250px;border-radius:5%">
        
        <ul class="list-group list-group-flush">
        <li class="list-group-item">Name: <?php echo e($m->name); ?></li>
          <li class="list-group-item">Role: <?php echo e($m->role); ?></li>
          <li class="list-group-item">Emp ID: <?php echo e($m->empid); ?></li>
          <li class="list-group-item">Email: <?php echo e($m->email); ?></li>
          <li class="list-group-item">Mobile: <?php echo e($m->mobile); ?></li>
          <li class="list-group-item">Date of Joining: <?php echo e($m->joiningdate); ?></li>
        </ul><a href="/members/<?php echo e($m->id); ?>/edit">
        <button type="button" class="btn btn-primary" style="margin-top:-28px;width:250px;">Update Profile</button></a>
      </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

</body>
</html>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\blog\resources\views/viewmember.blade.php ENDPATH**/ ?>