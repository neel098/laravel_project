


<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
    
    <meta charset="utf-8">
		<title>Add Board</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="../fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		
		
		<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<style>
		.profile_image{
			border-radius: 50%;
			width: 9.5%;
			margin-top: -210px;
			margin-left: -6px;
		}
		.profile_name{
			margin-top: -170px;
			margin-left: 125px;
			font-family: 'Times New Roman', Times, serif;
		}
	


		@import  url('https://fonts.googleapis.com/css?family=Raleway:300,400');
		body {
		background: #2D3142;
		font-family: 'Raleway', sans-serif;
		overflow-x:hidden;
		}


		/* Heading */

		h1 {
		font-size: 1.5em;
		text-align: center;
		padding: 70px 0 0 0;
		color: #EF8354;
		font-weight: 300;
		letter-spacing: 1px;
		}

		span {
		border: 2px solid #4F5D75;
		padding: 10px;
		}


		/* Layout Styling */

		#container-fluid {
		width: 100%;
		margin: 0 auto;
		padding: 50px 0 150px 0;
		display: flex;
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: center;
		margin-top: -60px;
		}


		/* Button Styles */

		.button {
		display: inline-flex;
		height: 40px;
		width: 150px;
		border: 2px solid #BFC0C0;
		margin: 20px 20px 20px 20px;
		color: #BFC0C0;
		text-transform: uppercase;
		text-decoration: none;
		font-size: .8em;
		letter-spacing: 1.5px;
		align-items: center;
		justify-content: center;
		overflow: hidden;
		}

		a {
		color: #BFC0C0;
		text-decoration: none;
		letter-spacing: 1px;
		}

		#button-5 {
		position: relative;
		overflow: hidden;
		cursor: pointer;
		}

		#button-5 a {
		position: relative;
		transition: all .45s ease-Out;
		}

		#translate {
		transform: rotate(50deg);
		width: 100%;
		height: 250%;
		left: -200px;
		top: -30px;
		background: #BFC0C0;
		position: absolute;
		transition: all .3s ease-Out;
		}

		#button-5:hover #translate {
		left: 0;
		}

		#button-5:hover a {
		color: #2D3142;
		}

		@media  screen and (min-width:1000px) {
		h1 {
			font-size: 2.2em;
		}
		#container {
			width: 50%;
		}
		}
        @import  url(https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,700italic);

*{margin: 0px; padding: 0px}

body{
background:#2c3e50;
font-family: 'Open Sans', sans-serif;
}

h1, button{
color:#fff;
text-align: center;
padding: 20px;
}

p{
color:#fff;
text-align: center;
padding-top: 500px;
font-size: 10px;
}

a{
text-decoration:none;
color:#fff;
}

a:hover{
color:#2ecc71;
}

.main{
width: 100%;
}

.sub-main{
width: 30%;
margin:22px;
float: left;
}

.button-one{
text-align: center;
cursor: pointer;
font-size:24px;
margin: 0 0 0 100px;
}



/*Button One*/
.button-one {
padding:20px 60px;
outline: none;
background-color: #27ae60;
border: none;
border-radius:5px;
box-shadow: 0 9px #95a5a6;
}

.button-one:hover{
background-color: #2ecc71;
}

.button-one:active {
background-color: #2ecc71;
box-shadow: 0 5px #95a5a6;
transform: translateY(4px);
}


	</style>
</head>
<body>
   
    <div>
        <div style="background-color: lightblue;height: 100px;" class="container-fluid">
                <div><img src="images\yuvaa_round.jpg" style="height: 180px;margin-left:1080px;" ></div>
        <div class="profile_name" style="margin-left:40px;margin-top:-160px"><h4>Welocme <br> <?php echo date("l"); echo ","; echo date("d,M,Y");	?></h4></div>
        </div>	
    </div>
    


<div id="container-fluid" class="container-fluid">

<div class="button" id="button-5">
    <div id="translate"></div>
    <a href="/dashboard">Home</a>
  </div>

  <div class="button" id="button-5">
    <div id="translate"></div>
    <a href="logout.php">Log Out</a>
  </div>

  <div class="wrapper" style="margin-left:234px;margin-top:-110px;background-image: url(<?php echo e(asset('images/bg-registration-form-2.jpg')); ?>);height:400px;margin-top:15px;width:2000px;">
    <div class="inner" style="margin-top:-0px;">
        <form action="/boards/<?php echo e($board->id); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>;
            <?php echo e(method_field('PATCH')); ?>

            <h3 style="margin-top:-18px;margin-left:-180px;">Update Details</h3>
            <div class="form-group" style="margin-left:-65px;">
                <div class="form-wrapper">
                    <label >Name</label>
                <input type="text" class="form-control" name="name" value="<?php echo e($board->name); ?>">
                </div>
                <div class="form-wrapper">
                <label >Email</label>
                <input type="email" class="form-control" name="email" value="<?php echo e($board->email); ?>">
            </div>
            <div class="form-wrapper" style="margin-left:20px;">
                <label >Mobile</label>
                <input type="tel" class="form-control" name="mobile" value="<?php echo e($board->mobile); ?>">
            </div>
            </div>
            

            <div class="form-group" style="margin-left:-65px;">
                
            
            <div class="form-wrapper" style="margin-left:2px;">
                <label >EMP ID</label>
            <input type="number" class="form-control" name="empid" value="<?php echo e($board->empid); ?>">
            </div>
            <div class="form-wrapper" style="margin-left:4px;">
                <label >Role</label>
            <input type="text" class="form-control" name="role" value="<?php echo e($board->role); ?>">
            </div>
            <div class="form-wrapper" style="margin-left:20px;">
                <label >Date of Joining</label>
                <input type="date" class="form-control" name="doj" value="<?php echo e($board->joiningdate); ?>">
            </div>
            </div>
            
            <button name="addboard" style="margin-left:47px;margin-top:-10px;width:248px;">Update Board Details</button>
        </form>
    </div>
</div>




</body>
</html>


















<?php /**PATH C:\Laravel\blog\resources\views/updateboard.blade.php ENDPATH**/ ?>