<?php $__env->startSection('content'); ?>
    


 
    
    <div style="margin-left: 260px;margin-top:38px;">
    
        <div>
    <div class="sub-main">
        <a href="/boards">
      <button class="button-one" style="width:313px;margin-left:0px;">View Board</button></a>
    </div>
    
    <div class="sub-main">
        <a href="/add_board">
      <button class="button-one" style="width:313px;margin-left:30px;">Add Board</button></a>
    </div>
    <div class="sub-main">
        <a href="/remove_board">
      <button class="button-one" style="width:313px;margin-left:0px;">Remove Board</button></a>
    </div>
    </div>
    
    
    <div>
    <div class="sub-main">
        <a href="/members">
      <button class="button-one" style="width:313px;margin-left:30px">View Member</button></a>
    </div>
    <div class="sub-main">
        <a href="/add_member">
      <button class="button-one" style="width: 313px;margin-left:0px;">Add Member</button></a>
    </div>
    <div class="sub-main">
        <a href="/remove_member">
      <button class="button-one" style="width:313px;margin-left:28px;">Remove Member</button></a>
    </div>
    </div>
    
    
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\blog\resources\views/dashboard.blade.php ENDPATH**/ ?>