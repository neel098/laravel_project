<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\admin;


class adminlogincontroller extends Controller
{
    
    public function start(Request $req){
        $email=$req->input('email');
        $password=$req->input('password');
        $log= new admin;
        $logs=$log::all();

        
        // return view('dashboard', 'logs');
        return view('dashboard', compact('logs'));
    }
}
