<?php

namespace App\Http\Controllers;

use App\member;
use Illuminate\Http\Request;

class memberscontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $member = new member;
        $members = $member::all();
        return view('viewmember',compact('members'));
    }


    public function indexremove()
    {
        $member = new member;
        $members = $member::all();
        return view('removemember',compact('members'));
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $profileimg = $request->file('profileimg');
        $new_name= rand() . '.' .  $profileimg->
                getClientOriginalExtension();
        $profileimg->move(public_path('images'),$new_name);



        $name=$request->name;
        $mobile=$request->mobile;
        $email=$request->email;
        $empid=$request->empid;
        $role=$request->role;
        $doj=$request->doj;

        $m=new \App\member;

        $m->name=$name;
        $m->mobile=$mobile;
        $m->email=$email;
        $m->empid=$empid;
        $m->joiningdate=$doj;
        $m->pimg = $new_name;

        $m->save();

        if ($m->save()) {
            ?>
            <script>
                alert("Data Inserted Succcesfully !!");
            </script>
            <?php
        }

        return view('addmember');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\member  $member
     * @return \Illuminate\Http\Response
     */
    public function show(member $member)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\member  $member
     * @return \Illuminate\Http\Response
     */
    public function edit(member $member)
    {
        return view('updatemember',compact('member'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\member  $member
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, member $member)
    {
        $member->name=$request->name;
        $member->empid=$request->empid;
        $member->joiningdate=$request->doj;
        $member->email=$request->email;
        $member->mobile=$request->mobile;

        $member->save();
        
        if ($member->save()) {
            ?>
            <script>
                alert("Records Updated Succcesfully !!");
            </script>
            <?php
        }

        return view('dashboard');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\member  $member
     * @return \Illuminate\Http\Response
     */
    public function destroy(member $member)
    {
        $member->delete();
        if ($member->delete()) {
            ?>
            <script>
                alert("Records Deleted Succcesfully !!");
            </script>
            <?php
        }
        return view('dashboard');
    }
}
