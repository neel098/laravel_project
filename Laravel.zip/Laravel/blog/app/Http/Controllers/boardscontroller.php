<?php

namespace App\Http\Controllers;

use App\board;
use Illuminate\Http\Request;

class boardscontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $board = new board;
        $boards = $board::all();
        return view('viewboard',compact('boards'));
        
    }

    public function indexremove()
    {
        $board = new board;
        $boards = $board::all();
        return view('removeboard',compact('boards'));
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $profileimg = $request->file('profileimg');
        $new_name= rand() . '.' .  $profileimg->
                getClientOriginalExtension();
        $profileimg->move(public_path('images'),$new_name);



        $name=$request->name;
        $mobile=$request->mobile;
        $email=$request->email;
        $empid=$request->empid;
        $role=$request->role;
        $doj=$request->doj;

        $b=new \App\board;

        $b->name=$name;
        $b->mobile=$mobile;
        $b->email=$email;
        $b->empid=$empid;
        $b->role=$role;
        $b->joiningdate=$doj;
        $b->pimg = $new_name;

        $b->save();

        if ($b->save()) {
            ?>
            <script>
                alert("Data Inserted Succcesfully !!");
            </script>
            <?php
        }

        return view('addboard');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\board  $board
     * @return \Illuminate\Http\Response
     */
    public function show(board $board)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\board  $board
     * @return \Illuminate\Http\Response
     */
    public function edit(board $board)
    {
        return view('updateboard',compact('board'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\board  $board
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, board $board)
    {
        $board->name=$request->name;
        $board->empid=$request->empid;
        $board->role=$request->role;
        $board->joiningdate=$request->doj;
        $board->email=$request->email;
        $board->mobile=$request->mobile;

        $board->save();
        
        if ($board->save()) {
            ?>
            <script>
                alert("Records Updated Succcesfully !!");
            </script>
            <?php
        }

        return view('dashboard');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\board  $board
     * @return \Illuminate\Http\Response
     */
    public function destroy(board $board)
    {
        $board->delete();
        if ($board->delete()) {
            ?>
            <script>
                alert("Records Deleted Succcesfully !!");
            </script>
            <?php
        }
        return view('dashboard');
    }
}
